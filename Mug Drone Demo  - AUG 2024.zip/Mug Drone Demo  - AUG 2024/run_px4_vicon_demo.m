% Script for starting PX4 Interface receiving telemetry data and receiving mocap data stream %%
%	Written by:    Pedro Mendes, 2019/08/29 - pmen817@aucklanduni.ac.nz
%	Last modified: Pedro Mendes, 2019/07/29 - pmen817@aucklanduni.ac.nz

clear all
clear
clc

%% Check if MinGW-w64 compiler to build MEX files is installed

addons_table=matlab.addons.installedAddons;
ming_installed=any(addons_table.Identifier=='ML_MINGW');

if ~ming_installed
    disp('***')
    disp('MinGW-w64 compiler is NOT installed');
    prompt='Do you want to install it (REQUIREMENT)? Y/N [Y]: ';
    str = upper(input(prompt,'s'));
    
    if isempty(str)
        str = 'Y';
    end
    
elseif (addons_table{(addons_table.Identifier=='ML_MINGW'),'Version'}>='19.1.0')
    disp('***')
    disp('Current version of MinGW-w64 compiler is already installed');
    str = 'N';
    
else
    disp('***')
    disp('Older version of MinGW-w64 compiler is installed');
    prompt='Do you want to update it (RECOMMENDED)? Y/N [Y]: ';
    str = upper(input(prompt,'s'));
    
    if isempty(str)
        str = 'Y';
    end
    
end

if str == 'Y'
    open('mingw.mlpkginstall')
end


clear addons_table k str prompt;

%% Check and compile TrackerSingleObjectParser and TrackerMultiObjectParser

singleparser_found=false;
multiparser_found=false;
files_list = dir;

for i=1:length(files_list)
    
    if strcmp(files_list(i).name,'TrackerSingleObjectParser.mexw64')
        disp('***')
        disp('TrackerSingleObjectParser already compiled');
        singleparser_found=true;
    end
    
    if strcmp(files_list(i).name,'TrackerMultiObjectParser.mexw64')
        disp('***')
        disp('TrackerMultiObjectParser already compiled');
        multiparser_found=true;
    end
    
end

clear i

if ~singleparser_found
    disp('***')
    disp('Compiling TrackerSingleObjectParser');
    mex TrackerSingleObjectParser.c
end

if ~multiparser_found
    disp('***')
    disp('Compiling TrackerMultiObjectParser');
    mex TrackerMultiObjectParser.c
end

clear singleparser_found multiparser_found;

%% Select the MAVLink header files for messages we want to use including

filenames = {
    %fullfile(fileparts(mfilename('fullpath')),'include\mavlink\v2.0\common\','mavlink_msg_heartbeat.h');
    %    fullfile(fileparts(mfilename('fullpath')),'include\mavlink\v2.0\common\','mavlink_msg_sys_status.h');
    fullfile(fileparts(mfilename('fullpath')),'include\mavlink\v2.0\common\','mavlink_msg_attitude.h');
    %     fullfile(fileparts(mfilename('fullpath')),'include\mavlink\v2.0\common\','mavlink_msg_highres_imu.h');
    %     fullfile(fileparts(mfilename('fullpath')),'include\mavlink\v2.0\common\','mavlink_msg_local_position_ned.h');
    %     fullfile(fileparts(mfilename('fullpath')),'include\mavlink\v2.0\common\','mavlink_msg_rc_channels.h');
    %     fullfile(fileparts(mfilename('fullpath')),'include\mavlink\v2.0\common\','mavlink_msg_servo_output_raw.h');
    fullfile(fileparts(mfilename('fullpath')),'include\mavlink\v2.0\common\','mavlink_msg_battery_status.h');
    };


%% Create encoder s-functions
% Calling create_sfun_encode will creates buses, header files, s-function
% cpp files, and will finally compile them. This will create one encoder
% s-function for each message


create_sfun_encode(fullfile(fileparts(mfilename('fullpath')),'include\mavlink\v2.0\common\','mavlink_msg_vision_position_estimate.h'));
create_sfun_encode(fullfile(fileparts(mfilename('fullpath')),'include\mavlink\v2.0\common\','mavlink_msg_set_position_target_local_ned.h'));
create_sfun_encode(fullfile(fileparts(mfilename('fullpath')),'include\mavlink\v2.0\common\','mavlink_msg_set_attitude_target.h'));

%% Create decider s-function
% Calling create_sfun_decode will creates buses, header files, s-function
% cpp file, and will finally compile it. This will create one decoder
% s-function in total

create_sfun_decode(filenames);

%% Check if Simulink Desktop Real-Time kernel is installed

% choose appropriate message based on currently installed version
k = RT.Kernel;
try
    kernel_installed = isInstalled(k);
catch
    kernel_installed = false;
end

if ~kernel_installed
    disp('***')
    disp('Simulink Desktop Real-Time kernel is NOT installed');
    prompt='Do you want to install it (REQUIREMENT)? Y/N [Y]: ';
    str = upper(input(prompt,'s'));
    
    if isempty(str)
        str = 'Y';
    end
    
elseif all(k.Version(1:3)==SLDRT.getInternalVersion)
    disp('***')
    disp('Current version of the Simulink Desktop Real-Time kernel is already installed');
    str = 'N';
    
else
    disp('***')
    disp('Older version of the Simulink Desktop Real-Time kernel is installed');
    prompt='Do you want to update it (RECOMMENDED)? Y/N [Y]: ';
    str = upper(input(prompt,'s'));
    
    if isempty(str)
        str = 'Y';
    end
    
end

if str == 'Y'
    sldrtkernel -install
end

clear k str prompt;

%% Run Simulink model
disp('***')

load('object1_name');
load('object2_name');
load('origin_track_char');

run px4_vicon_demo.slx
model = 'px4_vicon_demo';
        
prompt = {'Enter Object1 name:','Enter Object2 name:','Set Origin [x,y,z,yaw] - units in millimeters/rad'};
dlgtitle = 'Modify Object Name / Set Origin';
dims = [1 70];
definput = {Object1,Object2,origin_pos_yaw_char};
new_names = inputdlg(prompt,dlgtitle,dims,definput);

if ~isempty(new_names)
    Object1 = new_names{1};
    Object2 = new_names{2};
    origin_pos_yaw_char = new_names{3};
    save('object1_name.mat','Object1');
    save('object2_name.mat','Object2');
    save('origin_track_char.mat','origin_pos_yaw_char');
end

origin_pos_yaw = eval(origin_pos_yaw_char);

% answer = questdlg('Do you want to track only Object 1 or both objects?', ...
%     'Choose objects', ...
%     'Object 1','Both (Objects 1 and 2)','Cancel','Object 1');

% % Handle response
% switch answer
%     case 'Object 1'
%         disp([answer ' selected'])
%         set_param([model '/PX4-Vicon Link Code/Data Manipulation/SingleObjectParser'],'commented','off')
%         set_param([model '/PX4-Vicon Link Code/Data Manipulation/MultiObjectParser'],'commented','on')
%         set_param([model '/PX4-Vicon Link Code/Data Manipulation/Manipulation_Object2'],'commented','on')
%         obj_switch = 1;
%     case 'Both (Objects 1 and 2)'
%         disp([answer ' selected'])
%         set_param([model '/PX4-Vicon Link Code/Data Manipulation/MultiObjectParser'],'commented','off')
%         set_param([model '/PX4-Vicon Link Code/Data Manipulation/Manipulation_Object2'],'commented','off')
%         set_param([model '/PX4-Vicon Link Code/Data Manipulation/SingleObjectParser'],'commented','on')
%         obj_switch = -1;
%     case 'Cancel'
%         disp('PX4-Vicon_Link canceled and workspace cleaned')
% end

clear prompt dlgtitle dims definput
    